var flash = {
    alert: function(element, type, message, tag){
        element.html('<div class="alert alert-'+ type+'">'+ message+'</div> '+ tag+'').slideDown();
        return element;
    },
    hideAlert: function(){
        setTimeout(function(){
            var la = $('div .flash-alert');
            var hr = la.next();
            la.slideUp();
            hr.hide();
        }, 5000);
    }
};
(function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
(i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
})(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-135029468-1', 'auto');
ga('send', 'pageview');
