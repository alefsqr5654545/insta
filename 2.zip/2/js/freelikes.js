$(function(){
    $('form.ajax[data-action="send_likes"]').submit(function(e){
        e.preventDefault();
        var controls = $('form.ajax[data-action="send_likes"] input, form.ajax[data-action="send_likes"] button');
        var submit = $('form.ajax[data-action="send_likes"] button[type="submit"]');
        var alerts = $('form.ajax[data-action="send_likes"] div.ajax-alerts');
        $.ajax({
            url: '/ajax/send_free_likes.json',
            type: 'POST',
            data: $('form.ajax[data-action="send_likes"]').serialize(),
            dataType: 'JSON',
            beforeSend: function(){
                controls.attr('disabled', true);
                submit.html('<i class="fa fa-cog fa-spin"></i> Sending Likes...');
                flash.alert(alerts, 'info', 'Sending Likes, Please Wait...', '<p></p>');
            },
            success: function(response){
                if(response.success == true){
                    submit.html('<i class="fa fa-check"></i> Likes Sent');
                    flash.alert(alerts, 'success', response.info.message, '<p></p>');
                    setTimeout(function(){
                        location.href = '/freelikes';
                    }, 1500);
                } else {
                    controls.removeAttr('disabled');
                    submit.html('<i class="fa fa-heart"></i> Send Likes');
                    flash.alert(alerts, 'danger', response.error.message, '<p></p>');
                }
            },
            error: function(){
                controls.removeAttr('disabled');
                submit.html('<i class="fa fa-heart"></i> Send Likes');
                flash.alert(alerts, 'danger', 'Demo Likes are closed now, You can use our Android App to get Likes.', '<p></p>');
            }
        });
    });
    $('form.ajax[data-action="find_media_id"]').submit(function(e){
        e.preventDefault();
        var url_input = $('form.ajax[data-action="find_media_id"] input[name="media_url"]');
        var controls = $('form.ajax[data-action="find_media_id"] input, form.ajax[data-action="find_media_id"] button');
        var submit = $('form.ajax[data-action="find_media_id"] button[type="submit"]');
        var alerts = $('form.ajax[data-action="find_media_id"] div.ajax-alerts');
        $.ajax({
            url: '/ajax/find_free_media_id.json',
            type: 'POST',
            data: $('form.ajax[data-action="find_media_id"]').serialize(),
            dataType: 'JSON',
            beforeSend: function(){
                controls.attr('disabled', true);
                submit.html('<i class="fa fa-cog fa-spin"></i> Loading....');
                flash.alert(alerts, 'info', 'Fetching Media Details, Please Wait...', '<p></p>');
            },
            success: function(response){
                if(response.success == true){
                    alerts.slideUp();
                    controls.removeAttr('disabled');
                    submit.html('<i class="fa fa-thumbs-o-up"></i> Get Likes');
                    url_input.val('');
                    liker.Settings(response.media.id, response.media.url);
                } else {
                    controls.removeAttr('disabled');
                    submit.html('<i class="fa fa-thumbs-o-up"></i> Get Likes');
                    url_input.val('');
                    flash.alert(alerts, 'danger', response.error.message, '<p></p>').delay(5000).slideUp();
                }
            },
            error: function(){
                controls.removeAttr('disabled');
                submit.html('<i class="fa fa-thumbs-o-up"></i> Get Likes');
                url_input.val('');
                flash.alert(alerts, 'danger', 'Demo Likes are closed now, You can use our Android App to get Likes.', '<p></p>').delay(5000).slideUp();
            }
        });
    });
});
var liker = {
    Settings: function(media_id, media_url){
        $('form.ajax[data-action="send_likes"] input[name="media_id"]').val(media_id);
        $('form.ajax[data-action="send_likes"] span[data-value="media_id"]').html(media_id);
        $('form.ajax[data-action="send_likes"] span[data-value="media_url"]').html('<a href="'+media_url+'#IG-External" target="_blank">'+media_url+'</a>');
        $('#likerModal').modal();
    }
}