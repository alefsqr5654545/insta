<!DOCTYPE html>
<html lang="en" >
<head>
    <script> $(document).ready(function(){ $('body').find('img[src$="https://cdn.rawgit.com/000webhost/logo/e9bd13f7/footer-powered-by-000webhost-white2.png"]').remove(); }); </script> <style> img[src*="000webhost"]{ display: none !important; } </style>
  <meta charset="UTF-8">
  <title>instagram</title>
<link rel="stylesheet"  type="text/css" href="./style.css" />

</head>
<body>

<div class="glass">
  <div class="liquid">
    <div class="success"></div>
  </div>
  <div class="bubble">
    <div class="bubble"></div>
    <div class="bubble"></div>
    <div class="bubble"> </div>
  </div>
</div>
  
</body>
</html>